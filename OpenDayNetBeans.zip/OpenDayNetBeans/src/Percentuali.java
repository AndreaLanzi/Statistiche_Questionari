
public class Percentuali {
	private DatiCondivisi dati;
	
	public Percentuali(DatiCondivisi d)
	{
		dati=d;
	}
        
	
}
